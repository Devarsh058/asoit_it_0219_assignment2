function submitForm(event) {
    event.preventDefault(); // Prevent default form submission
  
    // Get form data
    var name = $("#name").val();
    var email = $("#email").val();
    var message = $("#message").val();
  
    // Perform validation (you can add more validation rules)
    if (name === '' || email === '' || message === '') {
      alert("Please fill in all fields.");
      return false;
    }
  
    // Simulate form submission
    alert("Feedback submitted successfully!");
    document.getElementById("feedback-form").reset(); // Reset the form
  }